-- Template wf-beam HB 500X200X10X16
INSERT INTO `qc_template` (`qc_template_id`, `prodtype_id`, `size_id`, `profile`, `std_dimention`, `brand_merek`, `specification`, `name`, `status`, `created_by`, `created_dt`, `updated_by`, `updated_dt`) VALUES
('TMP-wftjjgwl','WF-BEAM','HB 500X200X10X16','HB 500X200X10X16','500X200X10X16','WF-BEAM 500X200X10X16','HB 500X200X10X16','Template WF-BEAM 500X200X10X16','active','Akun Testing Manajer','2025-11-08 13:00:00','Akun Testing Manajer','2025-11-08 13:00:00');

INSERT INTO `qc_template_data` (`input_code`, `qc_template_id`, `label`, `input_type`, `min_tolerance`, `t_lt_50_tolerance`, `nominal_tolerance`, `t_gt_50_tolerance`, `max_tolerance`, `actual_tolerance`, `order_numb`, `enabled`, `sound`, `position`, `group_name`) VALUES
-- H-Top (1-3) - Width of Web (Tinggi Web)
('H.H-top','TMP-wftjjgwl','H(H-top)','number',497,498.5,500,501.5,503,NULL,1,1,'','H-Top','table'),
('C.H-top','TMP-wftjjgwl','C(H-top)','number',497,498.5,500,501.5,503,NULL,2,1,'','H-Top','table'),
('T.H-top','TMP-wftjjgwl','T(H-top)','number',497,498.5,500,501.5,503,NULL,3,1,'','H-Top','table'),

-- H-Center (4-6) - Width of Web (Tinggi Web)
('H.H-center','TMP-wftjjgwl','H(H-center)','number',497,498.5,500,501.5,503,NULL,4,1,'','H-Center','table'),
('C.H-center','TMP-wftjjgwl','C(H-center)','number',497,498.5,500,501.5,503,NULL,5,1,'','H-Center','table'),
('T.H-center','TMP-wftjjgwl','T(H-center)','number',497,498.5,500,501.5,503,NULL,6,1,'','H-Center','table'),

-- H-Bottom (7-9) - Width of Web (Tinggi Web)
('H.H-bottom','TMP-wftjjgwl','H(H-bottom)','number',497,498.5,500,501.5,503,NULL,7,1,'','H-Bottom','table'),
('C.H-bottom','TMP-wftjjgwl','C(H-bottom)','number',497,498.5,500,501.5,503,NULL,8,1,'','H-Bottom','table'),
('T.H-bottom','TMP-wftjjgwl','T(H-bottom)','number',497,498.5,500,501.5,503,NULL,9,1,'','H-Bottom','table'),

-- B1 (10-12) - Height of Flange (Lebar Kaki)
('H.B1','TMP-wftjjgwl','H(B1)','number',197,198.5,200,201.5,203,NULL,10,1,'','B1','table'),
('C.B1','TMP-wftjjgwl','C(B1)','number',197,198.5,200,201.5,203,NULL,11,1,'','B1','table'),
('T.B1','TMP-wftjjgwl','T(B1)','number',197,198.5,200,201.5,203,NULL,12,1,'','B1','table'),

-- B2 (13-15) - Height of Flange (Lebar Kaki)
('H.B2','TMP-wftjjgwl','H(B2)','number',197,198.5,200,201.5,203,NULL,13,1,'','B2','table'),
('C.B2','TMP-wftjjgwl','C(B2)','number',197,198.5,200,201.5,203,NULL,14,1,'','B2','table'),
('T.B2','TMP-wftjjgwl','T(B2)','number',197,198.5,200,201.5,203,NULL,15,1,'','B2','table'),

-- t1 (16-18) - Flange Thickness (Tebal Kaki)
('H.t1','TMP-wftjjgwl','H(t1)','number',14.5,15.25,16,16.75,17.5,NULL,16,1,'','t1','table'),
('C.t1','TMP-wftjjgwl','C(t1)','number',14.5,15.25,16,16.75,17.5,NULL,17,1,'','t1','table'),
('T.t1','TMP-wftjjgwl','T(t1)','number',14.5,15.25,16,16.75,17.5,NULL,18,1,'','t1','table'),

-- t2 (19-21) - Flange Thickness (Tebal Kaki)
('H.t2','TMP-wftjjgwl','H(t2)','number',14.5,15.25,16,16.75,17.5,NULL,19,1,'','t2','table'),
('C.t2','TMP-wftjjgwl','C(t2)','number',14.5,15.25,16,16.75,17.5,NULL,20,1,'','t2','table'),
('T.t2','TMP-wftjjgwl','T(t2)','number',14.5,15.25,16,16.75,17.5,NULL,21,1,'','t2','table'),

-- t3 (22-24) - Flange Thickness (Tebal Kaki)
('H.t3','TMP-wftjjgwl','H(t3)','number',14.5,15.25,16,16.75,17.5,NULL,22,1,'','t3','table'),
('C.t3','TMP-wftjjgwl','C(t3)','number',14.5,15.25,16,16.75,17.5,NULL,23,1,'','t3','table'),
('T.t3','TMP-wftjjgwl','T(t3)','number',14.5,15.25,16,16.75,17.5,NULL,24,1,'','t3','table'),

-- t4 (25-27) - Flange Thickness (Tebal Kaki)
('H.t4','TMP-wftjjgwl','H(t4)','number',14.5,15.25,16,16.75,17.5,NULL,25,1,'','t4','table'),
('C.t4','TMP-wftjjgwl','C(t4)','number',14.5,15.25,16,16.75,17.5,NULL,26,1,'','t4','table'),
('T.t4','TMP-wftjjgwl','T(t4)','number',14.5,15.25,16,16.75,17.5,NULL,27,1,'','t4','table'),

-- t5 (28-30) - Web Thickness (Tebal Web)
('H.t5','TMP-wftjjgwl','H(t5)','number',9.3,9.65,10,10.35,10.7,NULL,28,1,'','t5','table'),
('C.t5','TMP-wftjjgwl','C(t5)','number',9.3,9.65,10,10.35,10.7,NULL,29,1,'','t5','table'),
('T.t5','TMP-wftjjgwl','T(t5)','number',9.3,9.65,10,10.35,10.7,NULL,30,1,'','t5','table'),

-- b1 (31-33) - Flange Thickness (Tebal Kaki)
('H.b1','TMP-wftjjgwl','H(b1)','number',14.5,15.25,16,16.75,17.5,NULL,31,1,'','b1','table'),
('C.b1','TMP-wftjjgwl','C(b1)','number',14.5,15.25,16,16.75,17.5,NULL,32,1,'','b1','table'),
('T.b1','TMP-wftjjgwl','T(b1)','number',14.5,15.25,16,16.75,17.5,NULL,33,1,'','b1','table'),

-- b3 (34-36) - Flange Thickness (Tebal Kaki)
('H.b3','TMP-wftjjgwl','H(b3)','number',14.5,15.25,16,16.75,17.5,NULL,34,1,'','b3','table'),
('C.b3','TMP-wftjjgwl','C(b3)','number',14.5,15.25,16,16.75,17.5,NULL,35,1,'','b3','table'),
('T.b3','TMP-wftjjgwl','T(b3)','number',14.5,15.25,16,16.75,17.5,NULL,36,1,'','b3','table'),

-- b2 (37-39) - Flange Thickness (Tebal Kaki)
('H.b2','TMP-wftjjgwl','H(b2)','number',14.5,15.25,16,16.75,17.5,NULL,37,1,'','b2','table'),
('C.b2','TMP-wftjjgwl','C(b2)','number',14.5,15.25,16,16.75,17.5,NULL,38,1,'','b2','table'),
('T.b2','TMP-wftjjgwl','T(b2)','number',14.5,15.25,16,16.75,17.5,NULL,39,1,'','b2','table'),

-- b4 (40-42) - Flange Thickness (Tebal Kaki)
('H.b4','TMP-wftjjgwl','H(b4)','number',14.5,15.25,16,16.75,17.5,NULL,40,1,'','b4','table'),
('C.b4','TMP-wftjjgwl','C(b4)','number',14.5,15.25,16,16.75,17.5,NULL,41,1,'','b4','table'),
('T.b4','TMP-wftjjgwl','T(b4)','number',14.5,15.25,16,16.75,17.5,NULL,42,1,'','b4','table'),

-- b1-b2/2 (43-45) - Web Off Center (WOC)
('H.b1-b2/2','TMP-wftjjgwl','H(b1-b2/2)','number',-3.5,-1.75,0,1.75,3.5,NULL,43,1,'','b1-b2/2','table'),
('C.b1-b2/2','TMP-wftjjgwl','C(b1-b2/2)','number',-3.5,-1.75,0,1.75,3.5,NULL,44,1,'','b1-b2/2','table'),
('T.b1-b2/2','TMP-wftjjgwl','T(b1-b2/2)','number',-3.5,-1.75,0,1.75,3.5,NULL,45,1,'','b1-b2/2','table'),

-- b3-b4/2 (46-48) - Web Off Center (WOC)
('H.b3-b4/2','TMP-wftjjgwl','H(b3-b4/2)','number',-3.5,-1.75,0,1.75,3.5,NULL,46,1,'','b3-b4/2','table'),
('C.b3-b4/2','TMP-wftjjgwl','C(b3-b4/2)','number',-3.5,-1.75,0,1.75,3.5,NULL,47,1,'','b3-b4/2','table'),
('T.b3-b4/2','TMP-wftjjgwl','T(b3-b4/2)','number',-3.5,-1.75,0,1.75,3.5,NULL,48,1,'','b3-b4/2','table'),

-- FormRight (49-57)
('height.of.flange','TMP-wftjjgwl','Height of Flange','number',197,198.5,200,201.5,203,0,49,1,'','FormRight','Height of Flange'),
('flange.thickness','TMP-wftjjgwl','Flange Thickness','number',14.5,15.25,16,16.75,17.5,0,50,1,'','FormRight','Flange Thickness'),
('width.of.web','TMP-wftjjgwl','Width of Web','number',497,498.5,500,501.5,503,0,51,1,'','FormRight','Width of Web'),
('web.thickness','TMP-wftjjgwl','Web Thickness','number',9.3,9.65,10,10.35,10.7,0,52,1,'','FormRight','Web Thickness'),
('unit.weight','TMP-wftjjgwl','Unit Weight (Kgm)','number',84.7,86.45,88.2,89.95,91.7,0,53,1,'','FormRight','Unit Weight (Kgm)'),
('radius','TMP-wftjjgwl','Radius','number',0,0,13,0,0,0,54,1,'','FormRight','Radius'),
('web.off.center','TMP-wftjjgwl','Web Off Center','number',-3.5,-1.75,0,1.75,3.5,0,55,1,'','FormRight','Web Off Center'),
('os','TMP-wftjjgwl','OS','number',0,0,2.4,0,0,0,56,1,'','FormRight','OS'),
('cow','TMP-wftjjgwl','CoW','number',0,0,0,0,0,2.5,57,1,'','FormRight','CoW');

INSERT INTO `qc_template_mapping` (`mapping_id`, `qc_template_id`, `group_name`, `position`, `order_numb`) VALUES
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Width of Web', 'H-Top', 0),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Width of Web', 'H-Center', 1),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Width of Web', 'H-Bottom', 2),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Height of Flange', 'B1', 0),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Height of Flange', 'B2', 1),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Flange Thickness', 't1', 0),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Flange Thickness', 't2', 1),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Flange Thickness', 't3', 2),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Flange Thickness', 't4', 3),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Flange Thickness', 'b1', 4),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Flange Thickness', 'b2', 5),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Flange Thickness', 'b3', 6),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Flange Thickness', 'b4', 7),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Web Thickness', 't5', 0),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Web Off Center', 'b1-b2/2', 8),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Web Off Center', 'b3-b4/2', 9),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Radius', '', 0),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'CoW', '', 0),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'OS', '', 0),
(CONCAT('MAP', LEFT(UUID(),8)), 'TMP-wftjjgwl', 'Unit Weight (Kgm)', '', 0);